package com.accessproper

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View

class OrbView(c: Context) : View(c) {
    var level = 0f
    private var active = false
    private var t = 0f
    private val body = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2f; color = 0x33FFFFFF }
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 4200
        repeatCount = ValueAnimator.INFINITE
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }

    fun setActive(a: Boolean) { if (a != active) { active = a; build() } }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { build() }

    private fun build() {
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(width, height) * 0.28f
        if (r <= 0f) return
        val c = if (active) 0xFF5EF2E0.toInt() else 0xFFFF6B7A.toInt()
        val clear = Color.argb(0, Color.red(c), Color.green(c), Color.blue(c))
        val soft = Color.argb(120, Color.red(c), Color.green(c), Color.blue(c))
        glow.shader = RadialGradient(cx, cy, r * 1.9f, intArrayOf(soft, clear), floatArrayOf(0.4f, 1f), Shader.TileMode.CLAMP)
        body.shader = RadialGradient(cx - r * 0.3f, cy - r * 0.35f, r * 1.5f,
            intArrayOf(0xDDFFFFFF.toInt(), c, 0xFF9B8CFF.toInt()), floatArrayOf(0f, 0.38f, 1f), Shader.TileMode.CLAMP)
        invalidate()
    }

    override fun onDraw(cv: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(width, height) * 0.28f
        val s = 1f + 0.03f * Math.sin(t * 6.2832).toFloat() + level * 0.16f
        cv.save()
        cv.scale(s, s, cx, cy)
        cv.drawCircle(cx, cy, r * 1.9f, glow)
        cv.drawCircle(cx, cy, r, body)
        cv.drawCircle(cx, cy, r * 1.14f, ring)
        cv.restore()
    }
}

class MeterView(c: Context) : View(c) {
    private var lv = 0f
    private var th = 0f
    private var on = false
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    fun set(l: Float, t: Float, o: Boolean) { lv = l; th = t; on = o; invalidate() }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = h / 2
        p.color = 0x22FFFFFF
        cv.drawRoundRect(0f, 0f, w, h, r, r, p)
        val max = maxOf(th * 2.2f, 1f)
        val f = (lv / max).coerceIn(0f, 1f)
        p.color = if (on && lv > th) 0xFF4CFFA0.toInt() else 0xFF5EF2E0.toInt()
        cv.drawRoundRect(0f, 0f, maxOf(f * w, h), h, r, r, p)
        if (on) {
            p.color = 0xFFFFFFFF.toInt()
            val x = (th / max).coerceIn(0f, 1f) * w
            cv.drawRect(x - 2f, 0f, x + 2f, h, p)
        }
    }
}
