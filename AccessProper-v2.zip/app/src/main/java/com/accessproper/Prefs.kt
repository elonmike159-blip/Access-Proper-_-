package com.accessproper

import android.content.Context

class Prefs(c: Context) {
    private val p = c.applicationContext.getSharedPreferences("ap", Context.MODE_PRIVATE)

    var name: String
        get() = p.getString("name", "") ?: ""
        set(v) { p.edit().putString("name", v).apply() }
    var sens: Int
        get() = p.getInt("sens", 65)
        set(v) { p.edit().putInt("sens", v).apply() }
    var gap: Int
        get() = p.getInt("gap", 650)
        set(v) { p.edit().putInt("gap", v).apply() }
    var accel: Boolean
        get() = p.getBoolean("accel", false)
        set(v) { p.edit().putBoolean("accel", v).apply() }
    var f1n: String
        get() = p.getString("f1n", "") ?: ""
        set(v) { p.edit().putString("f1n", v).apply() }
    var f1p: String
        get() = p.getString("f1p", "") ?: ""
        set(v) { p.edit().putString("f1p", v).apply() }
    var f2n: String
        get() = p.getString("f2n", "") ?: ""
        set(v) { p.edit().putString("f2n", v).apply() }
    var f2p: String
        get() = p.getString("f2p", "") ?: ""
        set(v) { p.edit().putString("f2p", v).apply() }
    var notes: List<String>
        get() = (p.getString("notes", "") ?: "").split("\u0001").filter { it.isNotBlank() }
        set(v) { p.edit().putString("notes", v.joinToString("\u0001")).apply() }

    fun map(n: Int): String = p.getString("m$n", when (n) { 1 -> "down"; 2 -> "up"; 3 -> "back"; else -> "home" }) ?: "none"
    fun setMap(n: Int, v: String) { p.edit().putString("m$n", v).apply() }
}
