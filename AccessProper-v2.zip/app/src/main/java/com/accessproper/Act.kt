package com.accessproper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Path
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.KeyEvent
import android.widget.Toast

object Act {
    val items = listOf(
        "none" to "Do nothing",
        "down" to "Scroll down",
        "up" to "Scroll up",
        "back" to "Back",
        "home" to "Home",
        "recents" to "Recent apps",
        "notif" to "Notifications",
        "vol_up" to "Volume up",
        "vol_down" to "Volume down",
        "media" to "Play / pause",
        "torch" to "Flashlight",
        "shot" to "Screenshot",
        "lock" to "Lock screen",
        "tap" to "Tap screen centre",
        "app" to "Open app...",
        "call1" to "Call family 1",
        "call2" to "Call family 2"
    )

    private var torchOn = false

    fun appName(c: Context, pkg: String): String = try {
        c.packageManager.getApplicationLabel(c.packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { pkg }

    fun label(v: String, c: Context): String {
        if (v.startsWith("app:")) return "Open " + appName(c, v.substring(4))
        val p = Prefs(c)
        if (v == "call1") return "Call " + p.f1n.ifBlank { "family 1" }
        if (v == "call2") return "Call " + p.f2n.ifBlank { "family 2" }
        return items.firstOrNull { it.first == v }?.second ?: v
    }

    fun run(ctx: Context, v: String) {
        val s = AccessSvc.inst
        val g = AccessibilityService.GLOBAL_ACTION_BACK
        try {
            when {
                v == "none" -> return
                v == "down" -> s?.let { swipe(it, true) }
                v == "up" -> s?.let { swipe(it, false) }
                v == "back" -> s?.performGlobalAction(g)
                v == "home" -> s?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
                v == "recents" -> s?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS)
                v == "notif" -> s?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
                v == "shot" -> s?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
                v == "lock" -> s?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
                v == "tap" -> s?.let { tap(it) }
                v == "vol_up" -> vol(ctx, AudioManager.ADJUST_RAISE)
                v == "vol_down" -> vol(ctx, AudioManager.ADJUST_LOWER)
                v == "media" -> media(ctx)
                v == "torch" -> torch(ctx)
                v.startsWith("app:") -> {
                    val i = ctx.packageManager.getLaunchIntentForPackage(v.substring(4))
                    if (i != null) start(ctx, i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
                v == "call1" -> call(ctx, Prefs(ctx).f1p)
                v == "call2" -> call(ctx, Prefs(ctx).f2p)
            }
            if ((v in listOf("down", "up", "back", "home", "recents", "notif", "shot", "lock", "tap")) && s == null) {
                Toast.makeText(ctx, "Turn on Accessibility first", Toast.LENGTH_SHORT).show()
            }
            buzz(ctx)
        } catch (e: Exception) {
        }
    }

    private fun start(ctx: Context, i: Intent) {
        try { (AccessSvc.inst ?: ctx).startActivity(i) } catch (e: Exception) { }
    }

    private fun swipe(s: AccessibilityService, finger_up: Boolean) {
        val m = s.resources.displayMetrics
        val x = m.widthPixels / 2f
        val a = m.heightPixels * 0.72f
        val b = m.heightPixels * 0.28f
        val path = Path()
        if (finger_up) { path.moveTo(x, a); path.lineTo(x, b) } else { path.moveTo(x, b); path.lineTo(x, a) }
        s.dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 170)).build(), null, null)
    }

    private fun tap(s: AccessibilityService) {
        val m = s.resources.displayMetrics
        val path = Path()
        path.moveTo(m.widthPixels / 2f, m.heightPixels / 2f)
        s.dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 50)).build(), null, null)
    }

    private fun vol(c: Context, dir: Int) {
        c.getSystemService(AudioManager::class.java).adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
    }

    private fun media(c: Context) {
        val am = c.getSystemService(AudioManager::class.java)
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE))
    }

    private fun torch(c: Context) {
        val cm = c.getSystemService(CameraManager::class.java)
        val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true } ?: return
        torchOn = !torchOn
        cm.setTorchMode(id, torchOn)
    }

    private fun call(c: Context, num: String) {
        if (num.isBlank()) { Toast.makeText(c, "Add the number in the You tab", Toast.LENGTH_SHORT).show(); return }
        val ok = c.checkSelfPermission(android.Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        val i = Intent(if (ok) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(num)))
        start(c, i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun buzz(c: Context) {
        c.getSystemService(Vibrator::class.java)?.vibrate(VibrationEffect.createOneShot(25, 200))
    }
}
