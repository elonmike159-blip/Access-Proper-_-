package com.accessproper

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.Process
import android.os.SystemClock

class PulseService : Service(), SensorEventListener {

    companion object {
        @Volatile var running = false
        @Volatile var level = 0f
        @Volatile var thr = 0f
        @Volatile var status = "Standby"
        @Volatile var last = "none yet"
        @Volatile var restarts = 0

        fun start(c: Context) {
            val i = Intent(c, PulseService::class.java)
            c.startForegroundService(i)
        }
        fun stop(c: Context) { c.stopService(Intent(c, PulseService::class.java)) }
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var prefs: Prefs
    @Volatile private var alive = false
    private var thread: Thread? = null
    private var wl: PowerManager.WakeLock? = null
    private var sm: SensorManager? = null
    private val lock = Any()
    private var lastPulseAt = 0L
    private var count = 0
    private var gravity = 9.8f

    private val flush = Runnable {
        val n = count
        count = 0
        if (n > 0) {
            last = "$n pulse" + (if (n > 1) "s" else "")
            Act.run(this, prefs.map(minOf(n, 4)))
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (alive) return START_STICKY
        try {
            val n = notif()
            if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            else startForeground(1, n)
        } catch (e: Exception) {
            status = "Allow the microphone first"
            stopSelf()
            return START_NOT_STICKY
        }
        alive = true
        running = true
        status = "Starting..."
        wl = (getSystemService(Context.POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "accessproper:pulse").also { it.acquire() }
        thread = Thread({ loop() }, "pulse-audio").also { it.start() }
        registerAccel()
        return START_STICKY
    }

    override fun onDestroy() {
        alive = false
        running = false
        status = "Standby"
        level = 0f
        try { sm?.unregisterListener(this) } catch (e: Exception) { }
        try { wl?.release() } catch (e: Exception) { }
        main.removeCallbacks(flush)
        thread?.interrupt()
        super.onDestroy()
    }

    private fun notif(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("pulse", "Pulse listening", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, "pulse")
            .setContentTitle("AccessProper is listening")
            .setContentText("Pulse control is active")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    /** One pulse seen (from mic or motion). Shared refractory so both sources never double count. */
    private fun pulse(now: Long) {
        synchronized(lock) {
            if (now - lastPulseAt < 130) return
            lastPulseAt = now
        }
        main.post {
            count++
            main.removeCallbacks(flush)
            main.postDelayed(flush, prefs.gap.toLong())
        }
    }

    private fun make(sr: Int, fr: Int): AudioRecord? {
        val min = AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val size = maxOf(min, fr * 8)
        val sources = intArrayOf(MediaRecorder.AudioSource.UNPROCESSED, MediaRecorder.AudioSource.VOICE_RECOGNITION, MediaRecorder.AudioSource.MIC)
        for (src in sources) {
            try {
                val r = AudioRecord(src, sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, size)
                if (r.state == AudioRecord.STATE_INITIALIZED) return r
                r.release()
            } catch (e: Exception) { }
        }
        return null
    }

    private fun loop() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
        val sr = 16000
        val fr = 256 // 16 ms per frame
        val aHp = 0.9884f // ~30 Hz high-pass (removes DC and rumble)
        val aLp = 0.105f  // ~300 Hz low-pass, applied twice
        while (alive) {
            var rec: AudioRecord? = null
            try {
                rec = make(sr, fr)
                if (rec == null) {
                    status = "Microphone busy, retrying..."
                    restarts++
                    Thread.sleep(800)
                    continue
                }
                rec.startRecording()
                if (rec.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                    status = "Microphone busy, retrying..."
                    restarts++
                    Thread.sleep(800)
                    continue
                }
                status = "Calibrating, stay quiet..."
                val buf = ShortArray(fr)
                var hpY = 0f; var hpX = 0f; var lp1 = 0f; var lp2 = 0f
                var floor = -1f
                var calib = 0
                var inPulse = false
                var silentFrames = 0
                while (alive) {
                    val n = rec.read(buf, 0, fr)
                    if (n <= 0) break
                    var sum = 0.0
                    var nonZero = false
                    for (k in 0 until n) {
                        val x = buf[k].toFloat()
                        if (x != 0f) nonZero = true
                        hpY = aHp * (hpY + x - hpX); hpX = x
                        lp1 += aLp * (hpY - lp1)
                        lp2 += aLp * (lp1 - lp2)
                        sum += (lp2 * lp2).toDouble()
                    }
                    val e = Math.sqrt(sum / n).toFloat()
                    // ~3 s of pure digital silence means Android muted us: reopen the mic
                    silentFrames = if (nonZero) 0 else silentFrames + 1
                    if (silentFrames > 190) break

                    if (calib < 125) { // first 2 seconds learn the room noise
                        floor = if (floor < 0f) e else floor * 0.95f + e * 0.05f
                        calib++
                        level = e
                        thr = floor * 4f + 1.5f
                        if (calib == 125) status = "Listening"
                        continue
                    }
                    val ratio = 7.0f - 5.0f * (prefs.sens / 100f)
                    val t = floor * ratio + 1.5f
                    if (!inPulse) {
                        floor += if (e < floor) (e - floor) * 0.2f else (e - floor) * 0.004f
                        if (floor < 1f) floor = 1f
                    }
                    level = e
                    thr = t
                    if (!inPulse && e > t) {
                        inPulse = true
                        pulse(SystemClock.elapsedRealtime())
                    } else if (inPulse && e < t * 0.6f) {
                        inPulse = false
                    }
                }
                if (alive) { status = "Reconnecting mic..."; restarts++ }
            } catch (e: InterruptedException) {
                break
            } catch (e: Exception) {
                status = "Mic error, retrying..."
                restarts++
                try { Thread.sleep(500) } catch (x: InterruptedException) { break }
            } finally {
                try { rec?.stop() } catch (e: Exception) { }
                try { rec?.release() } catch (e: Exception) { }
            }
        }
    }

    private fun registerAccel() {
        if (!prefs.accel) return
        try {
            sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
            val s = sm?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) ?: return
            sm?.registerListener(this, s, SensorManager.SENSOR_DELAY_FASTEST)
        } catch (e: Exception) { }
    }

    override fun onSensorChanged(e: SensorEvent) {
        val m = Math.sqrt((e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2]).toDouble()).toFloat()
        gravity += (m - gravity) * 0.02f
        val d = Math.abs(m - gravity)
        val t = 2.4f - 1.8f * (prefs.sens / 100f)
        if (d > t) pulse(SystemClock.elapsedRealtime())
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
}
