package com.accessproper

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import java.util.Calendar

class MainActivity : Activity() {

    private class Step(val key: String, val title: String, val desc: String, val ok: Boolean, val go: () -> Unit)

    private lateinit var p: Prefs
    private val h = Handler(Looper.getMainLooper())
    private lateinit var body: LinearLayout
    private val navs = ArrayList<TextView>()
    private var tab = 0
    private var orb: OrbView? = null
    private var meter: MeterView? = null
    private var chip: TextView? = null
    private var dot: View? = null
    private var info: TextView? = null
    private var startBtn: TextView? = null
    private var permBox: LinearLayout? = null
    private val asked = HashSet<String>()

    private val BG = 0xFF070B14.toInt()
    private val CY = 0xFF5EF2E0.toInt()
    private val TX = 0xFFE8EDF7.toInt()
    private val MU = 0xFF8A94AD.toInt()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun lp(w: Int = -1, hh: Int = -2, top: Int = 0) =
        LinearLayout.LayoutParams(w, hh).apply { topMargin = dp(top) }

    private fun has(perm: String) = checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED

    // ---------- small UI helpers ----------
    private fun tv(t: String, size: Float = 14f, color: Int = TX, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(14))
        background = GradientDrawable().apply {
            cornerRadius = dp(22).toFloat(); setColor(0x14FFFFFF); setStroke(dp(1), 0x24FFFFFF)
        }
    }

    private fun pill(t: String, done: Boolean, click: () -> Unit) = TextView(this).apply {
        text = t; textSize = 13f; gravity = Gravity.CENTER
        setTextColor(if (done) CY else BG)
        setPadding(dp(16), dp(8), dp(16), dp(8))
        background = GradientDrawable().apply {
            cornerRadius = dp(20).toFloat()
            if (done) { setColor(0x00000000); setStroke(dp(1), CY) } else setColor(CY)
        }
        setOnClickListener { click() }
    }

    private fun field(hint: String, v: String, type: Int = InputType.TYPE_CLASS_TEXT, on: (String) -> Unit) = EditText(this).apply {
        setText(v); this.hint = hint; setHintTextColor(MU); setTextColor(TX); textSize = 15f
        inputType = type; setSingleLine()
        addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { on(s.toString()) }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
    }

    private fun seek(max: Int, value: Int, on: (Int) -> Unit) = SeekBar(this).apply {
        this.max = max; progress = value
        progressTintList = ColorStateList.valueOf(CY); thumbTintList = ColorStateList.valueOf(CY)
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { on(v) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
    }

    // ---------- lifecycle ----------
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        p = Prefs(this)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                gradientType = GradientDrawable.RADIAL_GRADIENT
                gradientRadius = dp(420).toFloat()
                setGradientCenter(0.5f, 0.12f)
                colors = intArrayOf(0xFF12303A.toInt(), BG)
            }
        }
        val sv = ScrollView(this).apply { overScrollMode = View.OVER_SCROLL_NEVER }
        body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(36), dp(18), dp(16))
        }
        sv.addView(body)
        root.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(0xFF0B1020.toInt())
        }
        listOf("Home", "Pulses", "Memory", "You").forEachIndexed { i, name ->
            val t = tv(name, 13f, MU).apply {
                gravity = Gravity.CENTER; setPadding(0, dp(14), 0, dp(14))
                setOnClickListener { show(i) }
            }
            navs.add(t)
            nav.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(nav, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
        show(0)
    }

    private val tick = object : Runnable {
        override fun run() { update(); h.postDelayed(this, 60) }
    }

    override fun onResume() {
        super.onResume()
        h.post(tick)
        if (tab == 0) fillPerms()
        guide()
    }

    override fun onPause() {
        h.removeCallbacks(tick)
        super.onPause()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (tab == 0) fillPerms()
        h.postDelayed({ guide() }, 300)
    }

    // ---------- permissions ----------
    private fun accOn(): Boolean {
        if (AccessSvc.inst != null) return true
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains("$packageName/")
    }

    private fun steps(): List<Step> {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        val l = ArrayList<Step>()
        l.add(Step("mic", "Microphone", "Hears your pulses", has(Manifest.permission.RECORD_AUDIO)) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        })
        l.add(Step("acc", "Accessibility", "Scroll, back, home, open apps", accOn()) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        if (Build.VERSION.SDK_INT >= 33) {
            l.add(Step("notif", "Notifications", "Shows the listening status", has(Manifest.permission.POST_NOTIFICATIONS)) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
            })
        }
        l.add(Step("call", "Phone calls", "Call family with one pulse", has(Manifest.permission.CALL_PHONE)) {
            requestPermissions(arrayOf(Manifest.permission.CALL_PHONE), 3)
        })
        l.add(Step("bat", "Keep running", "Stops Android killing the app (fixes signal drop)", pm.isIgnoringBatteryOptimizations(packageName)) {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        })
        l.add(Step("ovl", "Display over apps", "Lets calls and apps open from the background", Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        return l
    }

    /** Asks for each missing permission once per launch, one after another. */
    private fun guide() {
        for (s in steps()) {
            if (!s.ok && asked.add(s.key)) { s.go(); return }
        }
    }

    private fun fillPerms() {
        val box = permBox ?: return
        box.removeAllViews()
        for (s in steps()) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(8), 0, dp(8))
            }
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            col.addView(tv(s.title, 14f)); col.addView(tv(s.desc, 11f, MU))
            row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(pill(if (s.ok) "On" else "Allow", s.ok) { if (!s.ok) s.go() })
            box.addView(row)
        }
    }

    // ---------- tabs ----------
    private fun show(i: Int) {
        tab = i
        orb = null; meter = null; chip = null; dot = null; info = null; startBtn = null; permBox = null
        body.removeAllViews()
        when (i) { 0 -> home(); 1 -> pulses(); 2 -> memory(); else -> you() }
        navs.forEachIndexed { k, v -> v.setTextColor(if (k == i) CY else MU) }
    }

    private fun greeting(): String {
        val hr = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val g = if (hr < 5) "Good night" else if (hr < 12) "Good morning" else if (hr < 17) "Good afternoon" else "Good evening"
        return if (p.name.isBlank()) g else "$g, ${p.name}"
    }

    private fun home() {
        body.addView(tv("AccessProper", 18f).apply {
            letterSpacing = 0.15f; typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        })
        val o = OrbView(this); orb = o
        body.addView(o, lp(dp(240), dp(240), 6).apply { gravity = Gravity.CENTER_HORIZONTAL })

        val chipRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(7), dp(14), dp(7))
            background = GradientDrawable().apply { cornerRadius = dp(20).toFloat(); setColor(0x14FFFFFF); setStroke(dp(1), 0x24FFFFFF) }
        }
        val d = View(this).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFFFF5A6E.toInt()) } }
        dot = d
        chipRow.addView(d, LinearLayout.LayoutParams(dp(8), dp(8)).apply { rightMargin = dp(8) })
        val c = tv("Standby", 12f); chip = c
        chipRow.addView(c)
        body.addView(chipRow, lp(-2, -2, 0).apply { gravity = Gravity.CENTER_HORIZONTAL })

        body.addView(tv(greeting(), 24f).apply {
            gravity = Gravity.CENTER; typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        }, lp(-1, -2, 18))
        body.addView(tv("I'm here. What should we take care of?", 13f, MU).apply { gravity = Gravity.CENTER }, lp(-1, -2, 4))

        val sb = tv("Start listening", 16f, BG, true).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(14), 0, dp(14))
            background = GradientDrawable().apply { cornerRadius = dp(28).toFloat(); setColor(CY) }
            setOnClickListener { toggle() }
        }
        startBtn = sb
        body.addView(sb, lp(-1, -2, 18))

        // Signal card
        val sc = card()
        sc.addView(tv("Signal", 16f, TX, true))
        val m = MeterView(this); meter = m
        sc.addView(m, lp(-1, dp(14), 10))
        val inf = tv("", 12f, MU); info = inf
        sc.addView(inf, lp(-1, -2, 8))
        val sl = tv("Sensitivity ${p.sens}", 12f, MU)
        sc.addView(sl, lp(-1, -2, 8))
        sc.addView(seek(100, p.sens) { v -> p.sens = v; sl.text = "Sensitivity $v" })
        body.addView(sc, lp(-1, -2, 16))

        // Today card
        val tc = card()
        tc.addView(tv("Today", 16f, TX, true))
        val notes = p.notes
        if (notes.isEmpty()) tc.addView(tv("Nothing yet. Add tasks in Memory.", 12f, MU), lp(-1, -2, 6))
        else notes.take(3).forEach { tc.addView(tv("•  $it", 14f), lp(-1, -2, 6)) }
        body.addView(tc, lp(-1, -2, 12))

        // Family card
        val fc = card()
        fc.addView(tv("Family", 16f, TX, true))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        var any = false
        if (p.f1p.isNotBlank()) { any = true; row.addView(pill("Call " + p.f1n.ifBlank { "1" }, true) { Act.run(this, "call1") }, lp(-2, -2).apply { rightMargin = dp(10) }) }
        if (p.f2p.isNotBlank()) { any = true; row.addView(pill("Call " + p.f2n.ifBlank { "2" }, true) { Act.run(this, "call2") }) }
        if (any) fc.addView(row, lp(-1, -2, 10)) else fc.addView(tv("Add family numbers in the You tab.", 12f, MU), lp(-1, -2, 6))
        body.addView(fc, lp(-1, -2, 12))

        // Permissions card
        val pc = card()
        pc.addView(tv("Permissions", 16f, TX, true))
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        permBox = box
        pc.addView(box)
        body.addView(pc, lp(-1, -2, 12))
        fillPerms()
    }

    private fun toggle() {
        if (PulseService.running) {
            PulseService.stop(this)
        } else {
            if (!has(Manifest.permission.RECORD_AUDIO)) { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1); return }
            PulseService.start(this)
        }
    }

    private fun update() {
        val run = PulseService.running
        orb?.let {
            it.setActive(run)
            it.level = if (run) minOf(1f, PulseService.level / (PulseService.thr * 2f + 1f)) else 0f
        }
        meter?.set(PulseService.level, PulseService.thr, run)
        chip?.text = if (run) PulseService.status else "Standby"
        (dot?.background as? GradientDrawable)?.setColor(if (run) 0xFF4CFFA0.toInt() else 0xFFFF5A6E.toInt())
        startBtn?.text = if (run) "Stop listening" else "Start listening"
        info?.text = if (run) "Level ${PulseService.level.toInt()}  |  Trigger ${PulseService.thr.toInt()}  |  Last: ${PulseService.last}  |  Reconnects: ${PulseService.restarts}"
        else "Press Start, wait 2 seconds, then tap or hum against your chest."
    }

    private fun pulses() {
        body.addView(tv("Pulse actions", 22f).apply { typeface = Typeface.create("sans-serif-light", Typeface.NORMAL) })
        body.addView(tv("Tap a row to change it. Long-press a row to test it.", 12f, MU), lp(-1, -2, 4))
        for (n in 1..4) {
            val c = card()
            val t = tv("", 15f)
            fun upd() { t.text = "$n pulse${if (n > 1) "s" else ""}  >  ${Act.label(p.map(n), this)}" }
            upd()
            c.addView(t)
            c.setOnClickListener { choose(n) { upd() } }
            c.setOnLongClickListener { Act.run(this, p.map(n)); true }
            body.addView(c, lp(-1, -2, 12))
        }
        val gc = card()
        val gl = tv("Wait between pulses: ${p.gap} ms", 13f)
        gc.addView(gl)
        gc.addView(tv("Shorter is faster. Longer helps if 2 pulses count as 1.", 11f, MU))
        gc.addView(seek(900, p.gap - 300) { v -> p.gap = 300 + v; gl.text = "Wait between pulses: ${300 + v} ms" }, lp(-1, -2, 8))
        body.addView(gc, lp(-1, -2, 16))
        val mc = card()
        val sw = Switch(this).apply {
            text = "Motion assist (accelerometer)"; setTextColor(TX); isChecked = p.accel
            setOnCheckedChangeListener { _, v -> p.accel = v }
        }
        mc.addView(sw)
        mc.addView(tv("Also counts a sharp knock on the phone as a pulse. Applies on next Start. Can cause false triggers when walking.", 11f, MU))
        body.addView(mc, lp(-1, -2, 12))
    }

    private fun choose(n: Int, done: () -> Unit) {
        val labels = Act.items.map { it.second }.toTypedArray()
        AlertDialog.Builder(this).setTitle("$n pulse").setItems(labels) { _, i ->
            val id = Act.items[i].first
            if (id == "app") pickApp { pkg -> p.setMap(n, "app:$pkg"); done() }
            else { p.setMap(n, id); done() }
        }.show()
    }

    private fun pickApp(done: (String) -> Unit) {
        val pm = packageManager
        val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
        val names = list.map { it.loadLabel(pm).toString() }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Open which app?").setItems(names) { _, i ->
            done(list[i].activityInfo.packageName)
        }.show()
    }

    private fun memory() {
        body.addView(tv("Memory", 22f).apply { typeface = Typeface.create("sans-serif-light", Typeface.NORMAL) })
        body.addView(tv("Your tasks. Tap one to remove it.", 12f, MU), lp(-1, -2, 4))
        val c = card()
        val input = field("Add a task", "") {}
        c.addView(input)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun refill() {
            list.removeAllViews()
            p.notes.forEachIndexed { idx, s ->
                list.addView(tv("•  $s", 15f).apply {
                    setPadding(0, dp(10), 0, dp(10))
                    setOnClickListener { p.notes = p.notes.filterIndexed { k, _ -> k != idx }; refill() }
                })
            }
        }
        c.addView(pill("Add", false) {
            val t = input.text.toString().trim()
            if (t.isNotEmpty()) { p.notes = p.notes + t; input.setText(""); refill() }
        }, lp(-2, -2, 8))
        body.addView(c, lp(-1, -2, 12))
        val lc = card(); lc.addView(list)
        body.addView(lc, lp(-1, -2, 12))
        refill()
    }

    private fun you() {
        body.addView(tv("You", 22f).apply { typeface = Typeface.create("sans-serif-light", Typeface.NORMAL) })
        val nc = card()
        nc.addView(tv("Your name", 14f, MU))
        nc.addView(field("Shown in the greeting", p.name) { p.name = it })
        body.addView(nc, lp(-1, -2, 12))
        val fc = card()
        fc.addView(tv("Family 1", 14f, MU))
        fc.addView(field("Name", p.f1n) { p.f1n = it })
        fc.addView(field("Phone number", p.f1p, InputType.TYPE_CLASS_PHONE) { p.f1p = it })
        fc.addView(tv("Family 2", 14f, MU), lp(-1, -2, 10))
        fc.addView(field("Name", p.f2n) { p.f2n = it })
        fc.addView(field("Phone number", p.f2p, InputType.TYPE_CLASS_PHONE) { p.f2p = it })
        body.addView(fc, lp(-1, -2, 12))
        val tc = card()
        tc.addView(tv("If the signal drops (Realme)", 15f, TX, true))
        tc.addView(tv("1. Allow every permission on Home.\n2. Settings > Battery > App battery management > AccessProper > Allow background activity.\n3. Settings > App management > AccessProper > Auto-launch ON.\n4. Open Recent apps, long-press AccessProper, tap the lock icon.\n5. Keep the phone case from covering the microphone.", 12f, MU), lp(-1, -2, 6))
        body.addView(tc, lp(-1, -2, 12))
    }
}
